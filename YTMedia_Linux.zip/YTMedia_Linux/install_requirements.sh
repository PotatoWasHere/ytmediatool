#!/bin/bash
sudo apt update
sudo apt install -y python3-pip ffmpeg
pip3 install yt-dlp customtkinter
python3 YTMediaTool.py