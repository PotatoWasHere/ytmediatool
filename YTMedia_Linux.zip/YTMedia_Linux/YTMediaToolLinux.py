import sys
import os
import yt_dlp
import customtkinter as ctk
import threading
from tkinter import filedialog, messagebox
import webbrowser
import zipfile
import urllib.request

# --------------------------------------- Yapay zekâdan alınmıştır, ffmpeg'i yüklemek için!! ------------------------------------------------ #
import subprocess

def ensure_linux_ffmpeg():
    """Linux sistemlerde FFmpeg yüklü değilse otomatik kurar."""
    if sys.platform.startswith('linux'):
        try:
            # FFmpeg yüklü mü kontrol et
            subprocess.run(['ffmpeg', '-version'], check=True, capture_output=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("FFmpeg bulunamadı, yükleniyor...")
            try:
                # Pardus/Debian için otomatik yükleme komutu
                subprocess.run(['sudo', 'apt', 'update'], check=True)
                subprocess.run(['sudo', 'apt', 'install', '-y', 'ffmpeg'], check=True)
                return True
            except Exception as e:
                print(f"Yükleme hatası: {e}")
                return False
    return True
ensure_linux_ffmpeg()
# --------------------------------------- Yapay zekâdan alınmıştır, ffmpeg'i yüklemek için!! ------------------------------------------------ #

# --- çekirdek özellikler ---
def get_base_path():
    if getattr(sys, 'frozen', False):
        return sys._MEIPASS
    return os.path.dirname(__file__)

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class UltimateDownloader(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("YouTube Media Tool v2.1")
        self.geometry("850x700")

        # --- sidebar ---
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar.pack(side="left", fill="y")
        
        self.logo = ctk.CTkLabel(self.sidebar, text="MEDIA\nENGINE", font=("Roboto", 24, "bold"))
        self.logo.pack(pady=30)

        self.theme_btn = ctk.CTkButton(self.sidebar, text="Switch Theme", command=self.change_theme)
        self.theme_btn.pack(pady=10, padx=20)

        self.folder_btn = ctk.CTkButton(self.sidebar, text="Set Default Folder", command=self.set_default_folder)
        self.folder_btn.pack(pady=10, padx=20)

        self.help_btn = ctk.CTkButton(self.sidebar, text="Source Code/Help", fg_color="transparent", border_width=1, command=lambda: webbrowser.open("https://github.com/yt-dlp/yt-dlp"))
        self.help_btn.pack(side="bottom", pady=20, padx=20)

        # --- Main İçerik ---
        self.main_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.main_frame.pack(side="right", fill="both", expand=True, padx=30)

        self.header = ctk.CTkLabel(self.main_frame, text="Universal YouTube Media Downloader", font=("Roboto", 32, "bold"))
        self.header.pack(pady=(40, 10))

        # URL Input
        self.url_entry = ctk.CTkEntry(self.main_frame, placeholder_text="Paste Link or Type Search Keywords...", width=500, height=45)
        self.url_entry.pack(pady=10)

        # seçenekler yeri
        self.grid_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.grid_frame.pack(pady=10)

        # 1. format
        self.format_var = ctk.StringVar(value="mp4")
        self.fmt_menu = ctk.CTkOptionMenu(self.grid_frame, values=["mp4", "mp3", "mkv", "webm"], variable=self.format_var)
        self.fmt_menu.grid(row=0, column=0, padx=10)

        # 2. kalite
        self.quality_var = ctk.StringVar(value="Best")
        self.qual_menu = ctk.CTkOptionMenu(self.grid_frame, values=["Best", "1080p", "720p", "480p"], variable=self.quality_var)
        self.qual_menu.grid(row=0, column=1, padx=10)

        # 3. ekstralar
        self.thumb_var = ctk.BooleanVar(value=False)
        self.thumb_check = ctk.CTkCheckBox(self.grid_frame, text="Get Thumbnail", variable=self.thumb_var)
        self.thumb_check.grid(row=0, column=2, padx=10)

        # büyük download
        self.dl_button = ctk.CTkButton(self.main_frame, text="ENGAGE DOWNLOAD", height=60, width=400, font=("Roboto", 20, "bold"), command=self.start_task)
        self.dl_button.pack(pady=30)

        # ilerleme yeri
        self.status_label = ctk.CTkLabel(self.main_frame, text="System: Idle", font=("Roboto", 14))
        self.status_label.pack()
        self.progress_bar = ctk.CTkProgressBar(self.main_frame, width=500)
        self.progress_bar.set(0)
        self.progress_bar.pack(pady=10)

        # logları gösteriyor
        self.log_box = ctk.CTkTextbox(self.main_frame, height=200, width=550, font=("Consolas", 12))
        self.log_box.pack(pady=20)
        self.log_box.insert("0.0", "--- INITIALIZING SYSTEM ---\n> Ready for input.\n")

        self.default_dir = os.path.join(os.path.expanduser("~"), "Downloads")

    def change_theme(self):
        current = ctk.get_appearance_mode()
        ctk.set_appearance_mode("Light" if current == "Dark" else "Dark")

    def set_default_folder(self):
        path = filedialog.askdirectory()
        if path:
            self.default_dir = path
            self.log(f"Output Directory Set: {path}")

    def log(self, text):
        self.log_box.insert("end", f"> {text}\n")
        self.log_box.see("end")

    def progress_hook(self, d):
        if d['status'] == 'downloading':
            p = d.get('_percent_str', '0%').replace('%','')
            try:
                self.progress_bar.set(float(p) / 100)
                self.status_label.configure(text=f"Progress: {d.get('_percent_str')} | Speed: {d.get('_speed_str')}")
            except: pass

    def start_task(self):
        threading.Thread(target=self.download_logic, daemon=True).start()

    def download_logic(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showwarning("Input Error", "Please provide a link or search term.")
            return

        self.dl_button.configure(state="disabled", text="DOWNLOADING...")
        self.log(f"Processing Request: {url}")

        # --- LINUX UYUM GÜNCELLEMESİ BAŞLANGICI ---
        # FFmpeg konumunu işletim sistemine göre belirle
        if sys.platform.startswith('linux'):
            ffmpeg_path = '/usr/bin' # Pardus/Linux'ta standart konum
        else:
            ffmpeg_path = get_base_path() # Windows için mevcut klasör
        # --- LINUX UYUM GÜNCELLEMESİ SONU ---

        # kalite ayarlaması
        q_map = {"Best": "bestvideo+bestaudio/best", "1080p": "bestvideo[height<=1080]+bestaudio/best", 
                 "720p": "bestvideo[height<=720]+bestaudio/best", "480p": "bestvideo[height<=480]+bestaudio/best"}

        ydl_opts = {
            'outtmpl': f'{self.default_dir}/%(title)s.%(ext)s',
            'ffmpeg_location': ffmpeg_path, # Burası güncellendi!
            'progress_hooks': [self.progress_hook],
            'writethumbnail': self.thumb_var.get(),
            'format': q_map[self.quality_var.get()],
        }

        # link yoksa ytden arat
        if "http" not in url:
            url = f"ytsearch:{url}"
            self.log("Search mode activated...")

        # mp3 process gibimsi
        if self.format_var.get() == "mp3":
            ydl_opts.update({
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
            })

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info.get('title', 'Video') if 'entries' not in info else info['entries'][0]['title']
                self.log(f"SUCCESS: Finished {title}")
            
            # basit bir bildirim
            self.status_label.configure(text="Download Complete!")
        except Exception as e:
            self.log(f"CRITICAL ERROR: {str(e)}")
            messagebox.showerror("Download Failed", f"An error occurred: {str(e)}")

        self.dl_button.configure(state="normal", text="ENGAGE DOWNLOAD")
        self.progress_bar.set(0)

if __name__ == "__main__":
    app = UltimateDownloader()
    app.mainloop()