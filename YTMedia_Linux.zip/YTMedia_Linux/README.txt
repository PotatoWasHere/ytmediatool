Merhaba,

YouTube platformundan kolayca video ve ses indirmenizi sağlayan (playlist dahil), Python ile geliştirdiğim YouTube Media Tool projesini sizlerle paylaşıyorum.

Programın Özellikleri:
Virüslü sitelere son: Bu program ile tek yapıştırma ile YouTube videolarını kolayca indirebilirsiniz.

Format Seçenekleri: MP4, MP3, MKV ve WEBM desteği.

Akıllı Çözüm: Sistemde FFmpeg eksikse otomatik olarak tespit eder ve taşınabilir sürümü yapılandırır.

Modern Arayüz: Kullanıcı dostu, ilerleme çubuklu ve karanlık mod destekli tasarım.

Kurulum ve Çalıştırma:
Programın Pardus ve diğer Linux sistemlerde sorunsuz çalışması için gerekli tüm bağımlılıkları (FFmpeg, Python kütüphaneleri vb.) tek komutla kuran bir script hazırladım.

Klasör içinde terminali açıp şu komutu çalıştırmanız yeterlidir:

bash install_requirements.sh

Bu komut kurulumu tamamlayacak ve programı otomatik olarak başlatacaktır.

İyi kullanımlar!